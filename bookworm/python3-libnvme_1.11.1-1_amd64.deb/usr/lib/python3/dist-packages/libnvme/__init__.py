# SPDX-License-Identifier: LGPL-2.1-or-later
#
# This file is part of libnvme.
# Copyright (c) 2022 Dell Inc.
#
# Authors: Martin Belanger <Martin.Belanger@dell.com>

__version__ = "1.11.1"
__git_version__ = "1.11.1"
