#define RARVER_MAJOR     7
#define RARVER_MINOR    13
#define RARVER_BETA      0
#define RARVER_DAY      28
#define RARVER_MONTH     7
#define RARVER_YEAR   2025
