// wu.h
// See wu.c for details

int wu_quant(unsigned char *inbuf, int width, int height, int quant_to, png_color *pal);
