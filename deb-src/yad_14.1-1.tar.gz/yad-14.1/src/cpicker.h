#ifndef __CPICKER_H__
#define __CPICKER_H__

#include <gtk/gtk.h>

void yad_get_screen_color (GtkWidget *widget);

#endif /* __CPICKER_H__ */
