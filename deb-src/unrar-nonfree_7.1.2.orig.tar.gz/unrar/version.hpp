#define RARVER_MAJOR     7
#define RARVER_MINOR    10
#define RARVER_BETA      2
#define RARVER_DAY       4
#define RARVER_MONTH    12
#define RARVER_YEAR   2024
